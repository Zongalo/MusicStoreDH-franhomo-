<?php

include("funciones.php");
logout();
header("Location:home.php");exit;
