
 <br>
    <nav class="navbar navbar-inverse navbar-fixed-bottom hidden-xs">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Music Store DH</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Inicio</a></li>
      <li><a href="faq.php">Preguntas Frecuentes</a></li>
      <li><a href="#">Otros</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="registracion.php"><span class="glyphicon glyphicon-user"></span> Registrarse</a></li>
      <li><a href="inicio-de-sesion.php"><span class="glyphicon glyphicon-log-in"></span> Ingresar</a></li>
    </ul>
  </div>
</nav>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>


    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

    <!-- Custom Navbar Collapse Script Solution -->
    <script>
      $('.nav a').click(function() {
        $('.navbar-collapse').collapse('hide');
      });
    </script>
</body>

