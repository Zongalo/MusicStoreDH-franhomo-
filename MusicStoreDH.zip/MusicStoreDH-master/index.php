<?php include("header.php"); ?>

	<div class="container-fluid body-main-page">
        <section class="banner">
        	<img src="css/images/logo.png" alt="logotipo" class="logo logo-main">
			<img src="css/images/img-banner.jpg" alt="banner" class="banner-main">
			<div class="nav-header">
			<nav class="header-nav">
				<ul class="main-nav">
					<li class="header-nav"> <a href="#">HOME</a></li>
					<li class="header-nav"> <a href="#">CATEGORIAS</a></li>
					<li class="header-nav"> <a href="#">FAQ</a></li>
					<li class="header-nav"> <a href="#">CONTACTO</a></li>
				</ul>
			</nav>
			</div>
		</section>


        <!-- Título Novedades -->
        <div class="container body-main">
			<div class="row">
				<div class="título-home space">
				</div>
			</div>
        </div>
        <div class="row clearfix">


        <!-- Listado de productos -->
		<section class="vip-products">
					<article class="product">
						<img src="css/images/img-pdto-1.jpg" alt="pdto 01">
						<h2 class="product">Lorem ipsum amet</h2>
						<p class="product">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut recusandae eaque debitis sint necessitatibus, officia ex.</p>
						<a href="#" class="product">ver más</a>
					</article>
					<article class="product">
						<img src="css/images/img-pdto-1.jpg" alt="pdto 02">
						<h2 class="product">Lorem ipsum amet</h2>
						<p class="product">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut recusandae eaque debitis sint necessitatibus, officia ex.</p>
						<a href="#" class="product">ver más</a>
					</article>
					<article class="product">
						<img src="css/images/img-pdto-1.jpg" alt="pdto 03">
						<h2 class="product">Lorem ipsum amet</h2>
						<p class="product">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut recusandae eaque debitis sint necessitatibus, officia ex.</p>
						<a href="#" class="product">ver más</a>
					</article>
					<article class="product">
						<img src="css/images/img-pdto-1.jpg" alt="pdto 01">
						<h2 class="product">Lorem ipsum amet</h2>
						<p class="product">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut recusandae eaque debitis sint necessitatibus, officia ex.</p>
						<a href="#" class="product">ver más</a>
					</article>
					<article class="product">
						<img src="css/images/img-pdto-1.jpg" alt="pdto 02">
						<h2 class="product">Lorem ipsum amet</h2>
						<p class="product">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut recusandae eaque debitis sint necessitatibus, officia ex.</p>
						<a href="#" class="product">ver más</a>
					</article>
					<article class="product">
						<img src="css/images/img-pdto-1.jpg" alt="pdto 03">
						<h2 class="product">Lorem ipsum amet</h2>
						<p class="product">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut recusandae eaque debitis sint necessitatibus, officia ex.</p>
						<a href="#" class="product">ver más</a>
					</article>
		</section>




    <?php include("footer.php"); ?>

</body>


</html>
