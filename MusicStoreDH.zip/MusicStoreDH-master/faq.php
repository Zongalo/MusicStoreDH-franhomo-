<?php include("header.php"); ?>
        <br>
         <main>
        <section>
            <fieldset class="faq">
                <div class="col-md-4 col-md-offset-4 faq-master">
                    <div class="faq-head">
                    <img src="css/images/logo.png" alt="logotipo" class="logo-faq">
                    <div class="faq-header">
                        <strong class="h1">F.A.Q</strong class="h1">
                    </div>
                    </div>
                    <ul class="faq">
                     <li><strong  class="faq"> Cómo puedo registrarme en Music store?</strong></li>
                     <p class="faq">¡Es muy sencillo! Sólo tienes que ir a "Crear una cuenta" e introducir los datos que te solicitan.</p>
                     <li><strong  class="faq"> Cómo puedo pagar mi compra?</strong></li>
                     <p class="faq">Para realizar el pago de los productos puedes elegir entre diferentes métodos de pago: Tarjeta de credito, debito, efectivo o deposito bancario</p>
                     <li><strong  class="faq"> Cómo contacto con el departamento de Atención al Cliente?</strong></li>
                     <p class="faq">En Music store  ponemos a tu disposición varias vías de contacto:
                     Por teléfono, en el (+54) 0800-555-2323 te atenderemos encantados de Lunes a Viernes, entre las 9,30h y las 19h.
                     Enviándonos un correo electrónico a info@musicstore.com.</p>
                     <li><strong  class="faq"> Cuanto tiempo tengo que esperar para recibir mi pedido?</strong></li>
                     <p class="faq">Depende de la modalidad de envío seleccionada. Teniendo en cuenta que existen varias modalidades de acuerdo con las características de cada producto y la localización geográfica, el tiempo de entrega puede oscilar generalmente entre un mínimo de 24 horas y un máximo de 10 días hábiles.</p>
                     <li><strong  class="faq"> Es seguro comprar online en Music store?</strong></li>
                     <p class="faq">Comprar en musicstore.com es seguro.
                     Sus datos personales son tratados total seguridad y no son proporcionados bajo ningún concepto a terceros conforme a la Ley de Protección de Datos de Caracter Personal.</p>
                    </ul>
                </div>
            </fieldset>
        </section>
    </main>


