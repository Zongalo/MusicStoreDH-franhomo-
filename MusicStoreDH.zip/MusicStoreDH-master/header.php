<!DOCTYPE html>
<html>
<head>
    <!-- Declaro el viewport de media queries -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://code.jquery.com/jquery-2.2.4.min.js">
    <link href="https://fonts.googleapis.com/css?family=Permanent+Marker" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Monoton" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Bungee" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Black+Ops+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Hind+Vadodara" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="Faq.css">
    <link rel="stylesheet" type="text/css" href="Log-In.css">
    <link rel="stylesheet" type="text/css" href="Sing-in.css">
    <link rel="stylesheet" type="text/css" href="Mainpage.css">
    <title> Music Store DH</title>
<script src="/javascripts/application.js" type="text/javascript" charset="utf-8" async defer>
    $('.nav a').click(function() {
  $('.navbar-collapse').collapse('hide');
});
</script>
</head>
    <body>
    
<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
          </button>
              <span class="sr-only">Toggle navigation</span>
            <a class="navbar-brand" href="index.php">Music Store DH</a>
          </div>
             <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav">
            <li class="active"><a href="index.php">Inicio</a></li>
            <li><a href="#">Instrumentos</a></li>
            <li><a href="faq.php">Preguntas Frecuentes</a></li>

          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="registracion.php"><span class="glyphicon glyphicon-user"></span> Registrarse</a></li>
            <li><a href="inicio-de-sesion.php"><span class="glyphicon glyphicon-log-in"></span> Ingresar</a></li>
          </ul>
        </div>
      </div>

</nav>


